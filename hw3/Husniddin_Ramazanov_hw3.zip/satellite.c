#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <semaphore.h>
#include <errno.h>
#include "satellite.h"
#include "queue.h"

extern pthread_mutex_t engineerMutex;
extern sem_t newRequest, requestHandled;
extern int availableEngineers;
extern SatelliteQueue requestQueue;

void* satellite(void* arg) {
    int id = *(int*)arg;
    free(arg);
    
    // Generate random priority between 1-5
    srand(time(NULL) + id);
    int priority = rand() % 5 + 1;
    
    // Random wait time between 1-6 seconds
    int waitTime = rand() % 6 + 1;

    Satellite sat = { id, priority };

    printf("[SATELLITE] Satellite %d requesting (priority %d)\n", id, priority);

    pthread_mutex_lock(&engineerMutex);
    enqueue(&requestQueue, sat);
    pthread_mutex_unlock(&engineerMutex);

    sem_post(&newRequest);

    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    ts.tv_sec += waitTime;

    if (sem_timedwait(&requestHandled, &ts) == -1) {
        if (errno == ETIMEDOUT) {
            pthread_mutex_lock(&engineerMutex);
            // Check if we're still in the queue before removing
            int found = 0;
            for (int i = 0; i < requestQueue.size; ++i) {
                if (requestQueue.data[i].id == id) {
                    found = 1;
                    removeSatellite(&requestQueue, id);
                    break;
                }
            }
            pthread_mutex_unlock(&engineerMutex);
            
            if (found) {
                printf("[TIMEOUT] Satellite %d timeout %d second.\n", id, waitTime);
            }
        }
    }

    return NULL;
}