#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include "engineer.h"
#include "queue.h"
#include "stdlib.h"

extern pthread_mutex_t engineerMutex;
extern sem_t newRequest, requestHandled;
extern int availableEngineers;
extern SatelliteQueue requestQueue;

void* engineer(void* arg) {
    int id = *(int*)arg;
    free(arg);
    
    while (1) {
        sem_wait(&newRequest);

        pthread_mutex_lock(&engineerMutex);
        if (isEmpty(&requestQueue)) {
            pthread_mutex_unlock(&engineerMutex);
            continue;
        }
        Satellite sat = dequeue(&requestQueue);
        availableEngineers--;
        pthread_mutex_unlock(&engineerMutex);

        printf("[ENGINEER %d] Handling Satellite %d (Priority %d)\n", id, sat.id, sat.priority);
        
        // Simulate processing time (2 seconds)
        sleep(2);
        
        printf("[ENGINEER %d] Finished Satellite %d\n", id, sat.id);

        pthread_mutex_lock(&engineerMutex);
        availableEngineers++;
        pthread_mutex_unlock(&engineerMutex);

        sem_post(&requestHandled);
        
        // If all satellites are handled, exit
        pthread_mutex_lock(&engineerMutex);
        if (isEmpty(&requestQueue)) {
            pthread_mutex_unlock(&engineerMutex);
            printf("[ENGINEER %d] Exiting...\n", id);
            break;
        }
        pthread_mutex_unlock(&engineerMutex);
    }
    return NULL;
}