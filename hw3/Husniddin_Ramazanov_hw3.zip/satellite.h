#ifndef SATELLITE_H
#define SATELLITE_H

void* satellite(void* arg);

#endif